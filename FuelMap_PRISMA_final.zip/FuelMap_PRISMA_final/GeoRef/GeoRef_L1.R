install.packages("remotes")

remotes::install_github("lbusett/prismaread",force = TRUE)

testfile_L1 <- file.path("D:", "PhD","PRISMA","Bulgaria","PRS_L1_STD_OFFL_20220119092824_20220119092829_0001","PRS_L1_STD_OFFL_20220119092824_20220119092829_0001.he5", fsep="/")

out_folder_L1 <- file.path("D:", "PhD", "PRISMA","Bulgaria","PRS_L1_STD_OFFL_20220119092824_20220119092829_0001","New", fsep="/")

in_L2_file <- file.path("D:", "PhD","PRISMA","Bulgaria","PRS_L2C_STD_20220119092824_20220119092829_0001","PRS_L2C_STD_20220119092824_20220119092829_0001.he5", fsep="/")

library (prismaread)

pr_convert(in_file  = testfile_L1, in_L2_file = in_L2_file, out_folder = out_folder_L1, out_format = "GTiff", base_georef = TRUE, fill_gaps = TRUE, FULL = TRUE, 
           join_priority = "VNIR", LATLON = TRUE, PAN = TRUE, LC = TRUE, CLOUD = TRUE, overwrite = TRUE)


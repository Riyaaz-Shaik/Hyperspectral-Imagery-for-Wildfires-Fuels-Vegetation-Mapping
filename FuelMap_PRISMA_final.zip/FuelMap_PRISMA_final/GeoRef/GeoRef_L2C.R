install.packages("remotes")

remotes::install_github("lbusett/prismaread",force = TRUE)

testfile_l2c <- file.path("D:", "PhD","PRISMA", "PRS_L2C_STD_20210627101429_20210627101433_0001","PRS_L2C_STD_20210627101429_20210627101433_0001.he5", fsep="/")

out_folder_L2c <- file.path("D:", "PhD", "PRISMA", "PRS_L2C_STD_20210627101429_20210627101433_0001","New", fsep="/")

library (prismaread)

pr_convert(in_file  = testfile_l2c,out_folder = out_folder_L2c,out_format = "GTiff", fill_gaps = TRUE, FULL = TRUE, join_priority = "VNIR", ERR_MATRIX = TRUE,
           apply_errmatrix = TRUE, overwrite = TRUE)


